package edu.sti.shsregistration;

import android.content.Context;
import android.content.DialogInterface;
import android.content.res.Configuration;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.Color;
import android.os.Bundle;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.text.InputType;
import android.view.MenuItem;
import android.view.View;
import android.view.animation.AlphaAnimation;
import android.view.animation.Animation;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.RelativeLayout;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;


public class MainActivity extends AppCompatActivity {

        public Bundle extras = new Bundle();
        SQLiteDatabase db;
        CheckBox checkBox;
        CheckBox checkBox2;
        CheckBox checkBox3;
        CheckBox checkBox4;
        EditText Lname, Fname , Mname;
        EditText UsernameEt, PasswordEt;
        Button btLogin,btRegister;

        RadioGroup rbGroup;
        RadioButton rbGender1, rbGender2;
        Spinner spinner;
        int counter=0,btUpdateID,btCancelID,updateID;
        private ListView mDrawerList;
        private DrawerLayout mDrawerLayout;
        private ArrayAdapter<String> mAdapter;
        private ActionBarDrawerToggle mDrawerToggle;
        private String mActivityTitle;


        @Override
        protected void onCreate(Bundle savedInstanceState) {
                super.onCreate(savedInstanceState);
                setContentView(R.layout.activity_main);

                //TextView colorr = (TextView) findViewById(R.id.textView6);
                // final ColorStateList oldColors =  colorr.getTextColors();
                final Context context = this;

                db = openOrCreateDatabase("StudentDBB", Context.MODE_PRIVATE, null);

                db.execSQL("CREATE TABLE IF NOT EXISTS student(AProg VARCHAR,LName VARCHAR, FName VARCHAR, MName VARCHAR, Gender VARCHAR,Req1 VARCHAR,Req2 VARCHAR,Req3 VARCHAR,Req4 VARCHAR, ID INTEGER PRIMARY KEY DEFAULT NULL);");


                mDrawerList = (ListView)findViewById(R.id.navList);
                mDrawerLayout = (DrawerLayout)findViewById(R.id.drawer_layout);
                mActivityTitle = getTitle().toString();

                addDrawerItems();
                setupDrawer();

                getSupportActionBar().setDisplayHomeAsUpEnabled(true);
                getSupportActionBar().setHomeButtonEnabled(true);

                //Spinner declaration
                Spinner spinner = (Spinner) findViewById(R.id.spinner);
// Create an ArrayAdapter using the string array and a default spinner layout
                ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this,
                        R.array.planets_array, android.R.layout.simple_spinner_item);
// Specify the layout to use when the list of choices appears
                adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);

// Apply the adapter to the spinner
                spinner.setAdapter(adapter);





                //BUTTONS
                Button btAdd = (Button) findViewById(R.id.btAdd);
                btAdd.setOnClickListener(new View.OnClickListener() {

                        public void onClick(View v) {
                                // TODO Auto-generated method stub
                                Lname = (EditText) findViewById(R.id.editText);
                                int counter = 0;
                                Fname = (EditText) findViewById(R.id.editText2);
                                Mname = (EditText) findViewById(R.id.editText3);
                                checkBox = (CheckBox) findViewById(R.id.checkBox);
                                checkBox2 = (CheckBox) findViewById(R.id.checkBox2);
                                checkBox3 = (CheckBox) findViewById(R.id.checkBox3);
                                checkBox4 = (CheckBox) findViewById(R.id.checkBox4);
                                rbGroup = (RadioGroup) findViewById(R.id.radioGroup);



                                if(checkBox.isChecked()) {
                                        extras.putString("Req1", checkBox.getText().toString());
                                }
                                if(checkBox2.isChecked())
                                        extras.putString("Req2", checkBox2.getText().toString());
                                if(checkBox3.isChecked())
                                        extras.putString("Req3", checkBox3.getText().toString());
                                if(checkBox4.isChecked())
                                        extras.putString("Req4", checkBox4.getText().toString());


                                extras.putString("Last_Name", Lname.getText().toString());
                                extras.putString("First_Name", Fname.getText().toString());
                                extras.putString("Middle_Name", Mname.getText().toString());
                                Spinner spinner = (Spinner) findViewById(R.id.spinner);
                                extras.putString("Spinner", spinner.getSelectedItem().toString());


                                RadioButton radioButton = findViewById(R.id.radiobutton);
                                RadioButton radioButton2 = findViewById(R.id.radiobutton2);


                                //VALIDATIONS
                                if(!(radioButton.isChecked() || radioButton2.isChecked()))
                                {
                                        TextView test = (TextView) findViewById(R.id.textView11);
                                        Animation anim = new AlphaAnimation(0.0f, 1.0f);
                                        anim.setDuration(50); //You can manage the blinking time with this parameter
                                        anim.setStartOffset(20);
                                        anim.setRepeatMode(Animation.REVERSE);
                                        anim.setRepeatCount(2);
                                        test.startAnimation(anim);
                                        test.setError("Username Should not be blank");
                                        counter++;
                                }
                                else {
                                        TextView test = (TextView) findViewById(R.id.textView11);
                                        test.setError(null);
                                        if(radioButton.isChecked())
                                                extras.putString("radioData", radioButton.getText().toString());
                                        else
                                                extras.putString("radioData", radioButton2.getText().toString());
                                }
                                if(Lname.getText().toString().equalsIgnoreCase(""))
                                {
                                        TextView test = (TextView) findViewById(R.id.textView7);
                                        Animation anim = new AlphaAnimation(0.0f, 1.0f);
                                        anim.setDuration(50); //You can manage the blinking time with this parameter
                                        anim.setStartOffset(20);
                                        anim.setRepeatMode(Animation.REVERSE);
                                        anim.setRepeatCount(2);
                                        test.startAnimation(anim);
                                        test.setError("Username Should not be blank");
                                        counter++;
                                }
                                else {
                                        TextView test = (TextView) findViewById(R.id.textView7);
                                        test.setError(null);
                                }

                                if(Fname.getText().toString().equalsIgnoreCase(""))
                                {
                                        TextView test = (TextView) findViewById(R.id.textView8);
                                        Animation anim = new AlphaAnimation(0.0f, 1.0f);
                                        anim.setDuration(50); //You can manage the blinking time with this parameter
                                        anim.setStartOffset(20);
                                        anim.setRepeatMode(Animation.REVERSE);

                                        anim.setRepeatCount(2);
                                        test.startAnimation(anim);
                                        test.setError("Username Should not be blank");
                                        counter++;
                                }
                                else {
                                        TextView test = (TextView) findViewById(R.id.textView8);
                                        test.setError(null);
                                }
                                if(Mname.getText().toString().equalsIgnoreCase(""))
                                {
                                        TextView test = (TextView) findViewById(R.id.textView9);
                                        Animation anim = new AlphaAnimation(0.0f, 1.0f);
                                        anim.setDuration(50); //You can manage the blinking time with this parameter
                                        anim.setStartOffset(20);
                                        anim.setRepeatMode(Animation.REVERSE);
                                        anim.setRepeatCount(2);
                                        test.startAnimation(anim);
                                        test.setError("Username Should not be blank");
                                        counter++;
                                }
                                else {
                                        TextView test = (TextView) findViewById(R.id.textView9);
                                        test.setError(null);
                                }

                                if(spinner.getSelectedItemPosition() == 0)
                                {

                                }

                                //VALIDATIONS CONFIRMATION
                                if(counter >0)
                                {
                                        Toast.makeText(MainActivity.this, "Please fill up the necessary informations", Toast.LENGTH_SHORT).show();
                                        counter = 0;
                                }
                                else {
                                        //INTENT HEREEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEE

                                        db.execSQL("Insert into student values('"+extras.getString("Spinner")+"','"+ extras.getString("Last_Name")+"','"+extras.getString("First_Name") +"','"+extras.getString("Middle_Name")+"','"+extras.getString("radioData")+"','"+ extras.getString("Req1")+"','"+ extras.getString("Req2")+"','"+ extras.getString("Req3")+"','"+ extras.getString("Req4")+"',null);");
                                        Lname.setText(null);
                                        Lname.requestFocus();
                                        Fname.setText(null);
                                        Mname.setText(null);

                                        rbGroup.clearCheck();

                                        checkBox.setChecked(false);
                                        checkBox2.setChecked(false);
                                        checkBox3.setChecked(false);
                                        checkBox4.setChecked(false);
                                        displayResults("Record Added", "Input informations successfully added");
                                        extras.clear();


                                        // recreate();

                                }



                        }
                });















        }


        private void addDrawerItems() {
                String[] osArray = { "Delete", "Search", "View All", "Edit" };
                mAdapter = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, osArray);
                mDrawerList.setAdapter(mAdapter);

                mDrawerList.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                        @Override
                        public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                                // Toast.makeText(MainActivity.this, "Time for an upgrade! " + mDrawerList.getItemAtPosition(position).toString()
                                //  , Toast.LENGTH_SHORT).show();
                                if(position== 0) {
                                        final AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(
                                                MainActivity.this);
                                        alertDialogBuilder.setIcon(getResources().getDrawable(R.drawable.search));
                                        alertDialogBuilder.setTitle("Search a record to delete");
                                        // alertDialogBuilder.setMessage("Search by Last Name:");
                                        alertDialogBuilder.setCancelable(true);//.setPositiveButton("OK",
                                        //          new DialogInterface.OnClickListener() {
                                        //  public void onClick(DialogInterface dialog, int id) {
                                        // Cancels the dialog


                                        final EditText input = new EditText(MainActivity.this);
                                        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                                                LinearLayout.LayoutParams.WRAP_CONTENT,
                                                LinearLayout.LayoutParams.WRAP_CONTENT);
                                        input.setHint("Enter ID");
                                        input.setLayoutParams(lp);
                                        alertDialogBuilder.setView(input);
                                        input.setInputType(InputType.TYPE_CLASS_NUMBER);
                                        final  List<String> mTags = new ArrayList<String>();
                                        final ArrayList<String> lname = new ArrayList<String>();
                                        final ArrayList<String> fname = new ArrayList<String>();
                                        final ArrayList<String> mname = new ArrayList<String>();
                                        final ArrayList<String> studID = new ArrayList<String>();

                                        // final String[] fname = {};
                                        // final String[] mname = {};
                                        alertDialogBuilder.setPositiveButton("OK",
                                                new DialogInterface.OnClickListener() {
                                                        public void onClick(DialogInterface dialog,int which) {

                                                                if(input.getText().toString().equalsIgnoreCase(""))
                                                                {
                                                                        displayResults("", "No Results Found.");
                                                                }
                                                                else
                                                                {
                                                                        final AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity.this,R.style.Theme_AppCompat_Dialog_Alert);
                                                                        Cursor c = db.rawQuery("SELECT * FROM student", null);

                                                                        while (c.moveToNext())
                                                                        {
                                                                                if(String.valueOf(c.getInt(9)).contains(input.getText().toString()))
                                                                                {
                                                                                        mTags.add(c.getInt(9)+"  -  " + c.getString(1) + ", " + c.getString(2) + " " + c.getString(3));
                                                                                        lname.add(c.getString(1));
                                                                                        fname.add(c.getString(2));
                                                                                        mname.add(c.getString(3));
                                                                                        studID.add(Integer.toString(c.getInt(9)));
                                                                                }

                                                                        }

                                                                        final CharSequence[] tags = mTags.toArray(new String[mTags.size()]);

                                                                        if(tags.length==0)
                                                                        {
                                                                                displayResults("", "No Results Found.");
                                                                        }
                                                                        else {
                                                                                builder.setTitle("Records Found");
                                                                                builder.setItems(tags, new DialogInterface.OnClickListener() {
                                                                                        public void onClick(DialogInterface dialog, final int item) {
                                                                                                final AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(
                                                                                                        MainActivity.this, R.style.Theme_AppCompat_Dialog_Alert);
                                                                                                alertDialogBuilder.setTitle("Are you sure you want to delete this record?");
                                                                                                alertDialogBuilder.setMessage(studID.get(item)+ "  -  " +lname.get(item) + " ," + fname.get(item) + " " + mname.get(item));
                                                                                                alertDialogBuilder.setCancelable(true);
                                                                                                alertDialogBuilder.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                                                                                                        public void onClick(DialogInterface dialog, int which) {
                                                                                                                Cursor c = db.rawQuery("SELECT * FROM student WHERE LName='" + lname.get(item) + "'", null);
                                                                                                                if (c.moveToFirst()) {
                                                                                                                        db.execSQL("DELETE FROM Student WHERE LName='" + lname.get(item) + "' AND FNAME='" + fname.get(item) + "' AND MName='" + mname.get(item) + "'");
                                                                                                                        displayResults("Successfully Deleted", "");

                                                                                                                }
                                                                                                        }
                                                                                                });
                                                                                                alertDialogBuilder.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                                                                                                        public void onClick(DialogInterface dialog, int which) {

                                                                                                        }
                                                                                                });
                                                                                                alertDialogBuilder.show();


                                                                                        }
                                                                                });
                                                                                builder.show();
                                                                        }
                                    /*alertDialogBuilder.setItems(tags, new DialogInterface.OnClickListener() {
                                        public void onClick(DialogInterface dialog, int item) {
                                            Cursor c = db.rawQuery("SELECT * FROM students WHERE LName='"+ tags[item] + "'", null);
                                            if(c.moveToFirst())
                                            {
                                                db.execSQL("DELETE FROM students WHERE LName='" + tags[item] + "'");

                                            }
                                        }
                                    });*/

                                   /* if(buffer.toString().equalsIgnoreCase(""))
                                        displayResults("", "No Results Found.");
                                    else
                                        displayResults("Student Details", buffer.toString());*/
                                                                }

                                                        }
                                                });
                                        alertDialogBuilder.show();
                                }
                                if(position==1)
                                {
                                        AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(
                                                MainActivity.this);
                                        alertDialogBuilder.setIcon(getResources().getDrawable(R.drawable.search));
                                        alertDialogBuilder.setTitle("Search by ID:");
                                        // alertDialogBuilder.setMessage("Search by Last Name:");
                                        alertDialogBuilder.setCancelable(true);//.setPositiveButton("OK",
                                        //          new DialogInterface.OnClickListener() {
                                        //  public void onClick(DialogInterface dialog, int id) {
                                        // Cancels the dialog


                                        final EditText input = new EditText(MainActivity.this);
                                        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                                                LinearLayout.LayoutParams.WRAP_CONTENT,
                                                LinearLayout.LayoutParams.WRAP_CONTENT);
                                        input.setHint("Enter ID");
                                        input.setLayoutParams(lp);
                                        input.setInputType(InputType.TYPE_CLASS_NUMBER);
                                        alertDialogBuilder.setView(input);

                                        alertDialogBuilder.setPositiveButton("OK",
                                                new DialogInterface.OnClickListener() {
                                                        public void onClick(DialogInterface dialog,int which) {
                                                                if(input.getText().toString().equalsIgnoreCase(""))
                                                                {
                                                                        displayResults("", "No Results Found.");
                                                                }
                                                                else
                                                                {
                                                                        Cursor c = db.rawQuery("SELECT * FROM student ", null);
                                                                        StringBuffer buffer = new StringBuffer();
                                                                        while (c.moveToNext())
                                                                        {
                                                                                if(String.valueOf(c.getInt(9)).contains(input.getText().toString()))
                                                                                {
                                                                                        buffer.append("ID: " + c.getInt(9) + "\n");
                                                                                        buffer.append("Academic Program: " + c.getString(0) + "\n");
                                                                                        buffer.append("Name: " + c.getString(1) + ", " + c.getString(2) + " " + c.getString(3) + "\n");
                                                                                        buffer.append("Gender: " + c.getString(4) + "\n");
                                                                                        buffer.append("Requirements Submitted: " + "\n");

                                                                                        for (int a = 5; a < 9; a++) {
                                                                                                if (!(c.getString(a).equalsIgnoreCase("null")))
                                                                                                        buffer.append("\t•" + c.getString(a) + "\n");
                                                                                        }

                                                                                        buffer.append("\n\n");
                                                                                }
                                                                        }
                                                                        if(buffer.toString().equalsIgnoreCase(""))
                                                                                displayResults("", "No Results Found.");
                                                                        else
                                                                                displayResults("Student Details", buffer.toString());
                                                                }

                                                        }
                                                });
                                        alertDialogBuilder.show();

                                }
                                if(position==2)
                                {
                                        Cursor c = db.rawQuery("SELECT * FROM student", null);
                                        StringBuffer buffer = new StringBuffer();
                                        while (c.moveToNext())
                                        {
                                                buffer.append("ID: " + c.getInt(9) + "\n");
                                                buffer.append("Academic Program: " + c.getString(0) + "\n");
                                                buffer.append("Name: " + c.getString(1) + ", " + c.getString(2)+ " " + c.getString(3)+ "\n");
                                                buffer.append("Gender: " +c.getString(4) + "\n");
                                                buffer.append("Requirements Submitted: " + "\n");
                                                for(int a=5;a<9;a++)
                                                {
                                                        if(!(c.getString(a).equalsIgnoreCase("null")))
                                                                buffer.append("\t•" +c.getString(a) + "\n");
                                                }

                                                buffer.append("\n\n");
                                        }
                                        //Displaying all records
                                        if(buffer.toString().equalsIgnoreCase(""))
                                                displayResults("","No existing records yet.");
                                        else

                                                displayResults("Student Details", buffer.toString());
                                }



                                if(position==3)
                                {

                                        final  List<String> mTags = new ArrayList<String>();
                                        final ArrayList<String> lname = new ArrayList<String>();
                                        final ArrayList<String> fname = new ArrayList<String>();
                                        final ArrayList<String> mname = new ArrayList<String>();
                                        final ArrayList<String> studID = new ArrayList<String>();
                                        final AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity.this, R.style.Theme_AppCompat_Dialog_Alert);
                                        Cursor c = db.rawQuery("SELECT * FROM student", null);

                                        while (c.moveToNext())
                                        {
                                                mTags.add(c.getInt(9)+"  -  " + c.getString(1) + ", " + c.getString(2) + " " + c.getString(3));
                                                lname.add(c.getString(1));
                                                fname.add(c.getString(2));
                                                mname.add(c.getString(3));
                                                studID.add(Integer.toString(c.getInt(9)));
                                        }

                                        final CharSequence[] tags = mTags.toArray(new String[mTags.size()]);

                                        if(tags.length==0)
                                        {
                                                displayResults("", "No Results Found.");
                                        }
                                        else {

                                                builder.setTitle("Records List");

                                                builder.setItems(tags, new DialogInterface.OnClickListener() {
                                                        public void onClick(DialogInterface dialog, final int item) {
                                                                Lname = (EditText) findViewById(R.id.editText);
                                                                Fname = (EditText) findViewById(R.id.editText2);
                                                                Mname = (EditText) findViewById(R.id.editText3);
                                                                rbGender1 = findViewById(R.id.radiobutton);
                                                                rbGender2 = findViewById(R.id.radiobutton2);
                                                                checkBox  = (CheckBox) findViewById(R.id.checkBox);
                                                                checkBox2  = (CheckBox) findViewById(R.id.checkBox2);
                                                                checkBox3  = (CheckBox) findViewById(R.id.checkBox3);
                                                                checkBox4  = (CheckBox) findViewById(R.id.checkBox4);
                                                                spinner = (Spinner) findViewById(R.id.spinner);
                                                                rbGroup = (RadioGroup) findViewById(R.id.radioGroup);
                                                                final Button add = (Button) findViewById(R.id.btAdd);
                                                                mDrawerLayout = (DrawerLayout)findViewById(R.id.drawer_layout);
                                                                RelativeLayout rl = (RelativeLayout) findViewById(R.id.r1);
                                                                Cursor c = db.rawQuery("SELECT * FROM student where id="+ String.valueOf(studID.get(item)), null);
                                                                updateID= Integer.parseInt(studID.get(item));
                                                                if(c.moveToFirst()) {

                                                                        for (int a = 0; a < 5; a++) {
                                                                                if (spinner.getItemAtPosition(a).toString().equalsIgnoreCase(c.getString(0)))
                                                                                        spinner.setSelection(a);


                                                                        }
                                                                        Lname.setText(c.getString(1));
                                                                        Fname.setText(c.getString(2));
                                                                        Mname.setText(c.getString(3));

                                                                        if(c.getString(4).equalsIgnoreCase("Male")) {
                                                                                rbGender1.setChecked(true);
                                                                                rbGender2.setChecked(false);

                                                                        }
                                                                        else if(c.getString(4).equalsIgnoreCase("Female"))
                                                                        {
                                                                                rbGender2.setChecked(true);
                                                                                rbGender1.setChecked(false);
                                                                        }
                                                                        else if(c.getString(4).equalsIgnoreCase("null"))
                                                                        {
                                                                                rbGroup.clearCheck();
                                                                        }



                                                                        if (!(c.getString(5).equalsIgnoreCase("null")))
                                                                                checkBox.setChecked(true);
                                                                        else
                                                                                checkBox.setChecked(false);
                                                                        if (!(c.getString(6).equalsIgnoreCase("null")))
                                                                                checkBox2.setChecked(true);
                                                                        else
                                                                                checkBox2.setChecked(false);
                                                                        if (!(c.getString(7).equalsIgnoreCase("null")))
                                                                                checkBox3.setChecked(true);
                                                                        else
                                                                                checkBox3.setChecked(false);
                                                                        if (!(c.getString(8).equalsIgnoreCase("null")))
                                                                                checkBox4.setChecked(true);
                                                                        else
                                                                                checkBox4.setChecked(false);

                                                                        mDrawerLayout.closeDrawers();


                                                                        if (counter == 0)
                                                                        {
                                                                                final Button update = new Button(MainActivity.this);
                                                                                final Button cancel = new Button(MainActivity.this);
                                                                                RelativeLayout.LayoutParams lp = new RelativeLayout.LayoutParams(
                                                                                        RelativeLayout.LayoutParams.WRAP_CONTENT,
                                                                                        RelativeLayout.LayoutParams.WRAP_CONTENT);
                                                                                RelativeLayout.LayoutParams lp2 = new RelativeLayout.LayoutParams(
                                                                                        RelativeLayout.LayoutParams.WRAP_CONTENT,
                                                                                        RelativeLayout.LayoutParams.WRAP_CONTENT);
                                                                                lp.addRule(RelativeLayout.ALIGN_PARENT_BOTTOM, RelativeLayout.TRUE);
                                                                                lp.addRule(RelativeLayout.ALIGN_PARENT_LEFT, RelativeLayout.TRUE);
                                                                                update.setBackgroundColor(Color.parseColor("#00a6ff"));
                                                                                update.setText("Update");
                                                                                update.setId(View.generateViewId());
                                                                                btUpdateID= update.getId();
                                                                                cancel.setText("Cancel");
                                                                                cancel.setId(View.generateViewId());
                                                                                btCancelID= cancel.getId();
                                                                                cancel.setBackgroundColor(Color.parseColor("#00a6ff"));
                                                                                lp2.addRule(RelativeLayout.ALIGN_PARENT_BOTTOM, RelativeLayout.TRUE);
                                                                                lp2.addRule(RelativeLayout.ALIGN_PARENT_RIGHT, RelativeLayout.TRUE);
                                                                                rl.addView(update, lp);
                                                                                rl.addView(cancel, lp2);
                                                                                add.setVisibility(View.INVISIBLE);

                                                                                update.setOnClickListener(new View.OnClickListener() {
                                                                                        public void onClick(View view) {
                                                                                                AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(
                                                                                                        MainActivity.this);

                                                                                                alertDialogBuilder.setMessage("Are you sure you wanna save the changes?");
                                                                                                alertDialogBuilder.setPositiveButton("Yes",
                                                                                                        new DialogInterface.OnClickListener() {
                                                                                                                public void onClick(DialogInterface dialog, int which) {
                                                                                                                        // TODO Auto-generated method stub
                                                                                                                        Lname = (EditText) findViewById(R.id.editText);
                                                                                                                        int counter = 0;
                                                                                                                        Fname = (EditText) findViewById(R.id.editText2);
                                                                                                                        Mname = (EditText) findViewById(R.id.editText3);
                                                                                                                        checkBox = (CheckBox) findViewById(R.id.checkBox);
                                                                                                                        checkBox2 = (CheckBox) findViewById(R.id.checkBox2);
                                                                                                                        checkBox3 = (CheckBox) findViewById(R.id.checkBox3);
                                                                                                                        checkBox4 = (CheckBox) findViewById(R.id.checkBox4);



                                                                                                                        if (checkBox.isChecked()) {
                                                                                                                                extras.putString("Req1", checkBox.getText().toString());
                                                                                                                        }
                                                                                                                        if (checkBox2.isChecked())
                                                                                                                                extras.putString("Req2", checkBox2.getText().toString());
                                                                                                                        if (checkBox3.isChecked())
                                                                                                                                extras.putString("Req3", checkBox3.getText().toString());
                                                                                                                        if (checkBox4.isChecked())
                                                                                                                                extras.putString("Req4", checkBox4.getText().toString());


                                                                                                                        extras.putString("Last_Name", Lname.getText().toString());
                                                                                                                        extras.putString("First_Name", Fname.getText().toString());
                                                                                                                        extras.putString("Middle_Name", Mname.getText().toString());
                                                                                                                        Spinner spinner = (Spinner) findViewById(R.id.spinner);
                                                                                                                        extras.putString("Spinner", spinner.getSelectedItem().toString());


                                                                                                                        RadioButton radioButton = (RadioButton) findViewById(R.id.radiobutton);
                                                                                                                        RadioButton radioButton2 = (RadioButton) findViewById(R.id.radiobutton2);


                                                                                                                        //VALIDATIONS
                                                                                                                        if (!(radioButton.isChecked() || radioButton2.isChecked())) {
                                                                                                                                TextView test = (TextView) findViewById(R.id.textView11);
                                                                                                                                Animation anim = new AlphaAnimation(0.0f, 1.0f);
                                                                                                                                anim.setDuration(50); //You can manage the blinking time with this parameter
                                                                                                                                anim.setStartOffset(20);
                                                                                                                                anim.setRepeatMode(Animation.REVERSE);
                                                                                                                                anim.setRepeatCount(2);
                                                                                                                                test.startAnimation(anim);
                                                                                                                                test.setError("Username Should not be blank");
                                                                                                                                counter++;
                                                                                                                        } else {
                                                                                                                                TextView test = (TextView) findViewById(R.id.textView11);
                                                                                                                                test.setError(null);
                                                                                                                                if(radioButton.isChecked())
                                                                                                                                        extras.putString("radioData", radioButton.getText().toString());
                                                                                                                                else
                                                                                                                                        extras.putString("radioData", radioButton2.getText().toString());
                                                                                                                        }
                                                                                                                        if (Lname.getText().toString().equalsIgnoreCase("")) {
                                                                                                                                TextView test = (TextView) findViewById(R.id.textView7);
                                                                                                                                Animation anim = new AlphaAnimation(0.0f, 1.0f);
                                                                                                                                anim.setDuration(50); //You can manage the blinking time with this parameter
                                                                                                                                anim.setStartOffset(20);
                                                                                                                                anim.setRepeatMode(Animation.REVERSE);
                                                                                                                                anim.setRepeatCount(2);
                                                                                                                                test.startAnimation(anim);
                                                                                                                                test.setError("Username Should not be blank");
                                                                                                                                counter++;
                                                                                                                        } else {
                                                                                                                                TextView test = (TextView) findViewById(R.id.textView7);
                                                                                                                                test.setError(null);
                                                                                                                        }

                                                                                                                        if (Fname.getText().toString().equalsIgnoreCase("")) {
                                                                                                                                TextView test = (TextView) findViewById(R.id.textView8);
                                                                                                                                Animation anim = new AlphaAnimation(0.0f, 1.0f);
                                                                                                                                anim.setDuration(50); //You can manage the blinking time with this parameter
                                                                                                                                anim.setStartOffset(20);
                                                                                                                                anim.setRepeatMode(Animation.REVERSE);
                                                                                                                                anim.setRepeatCount(2);
                                                                                                                                test.startAnimation(anim);
                                                                                                                                test.setError("Username Should not be blank");
                                                                                                                                counter++;
                                                                                                                        } else {
                                                                                                                                TextView test = (TextView) findViewById(R.id.textView8);
                                                                                                                                test.setError(null);
                                                                                                                        }
                                                                                                                        if (Mname.getText().toString().equalsIgnoreCase("")) {
                                                                                                                                TextView test = (TextView) findViewById(R.id.textView9);
                                                                                                                                Animation anim = new AlphaAnimation(0.0f, 1.0f);
                                                                                                                                anim.setDuration(50); //You can manage the blinking time with this parameter
                                                                                                                                anim.setStartOffset(20);
                                                                                                                                anim.setRepeatMode(Animation.REVERSE);
                                                                                                                                anim.setRepeatCount(2);
                                                                                                                                test.startAnimation(anim);
                                                                                                                                test.setError("Username Should not be blank");
                                                                                                                                counter++;
                                                                                                                        } else {
                                                                                                                                TextView test = (TextView) findViewById(R.id.textView9);
                                                                                                                                test.setError(null);
                                                                                                                        }

                                                                                                                        if (spinner.getSelectedItemPosition() == 0) {

                                                                                                                        }

                                                                                                                        //VALIDATIONS CONFIRMATION
                                                                                                                        if (counter > 0) {
                                                                                                                                Toast.makeText(MainActivity.this, "Please fill up the necessary informations", Toast.LENGTH_SHORT).show();
                                                                                                                                counter = 0;
                                                                                                                        } else {
                                                                                                                                //INTENT HEREEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEE

                                                                                                                                db.execSQL("Update student SET AProg ='" + extras.getString("Spinner") + "', LName='" + extras.getString("Last_Name") + "',FName='" + extras.getString("First_Name") + "',MName='" + extras.getString("Middle_Name") + "',Gender='" + extras.getString("radioData") + "',Req1='" + extras.getString("Req1") + "',Req2='" + extras.getString("Req2") + "',Req3='" + extras.getString("Req3") + "',Req4='" + extras.getString("Req4") + "' where ID=" + updateID + ";");

                                                                                                                                Lname.setText(null);
                                                                                                                                Lname.requestFocus();
                                                                                                                                Fname.setText(null);
                                                                                                                                Mname.setText(null);

                                                                                                                                rbGroup.clearCheck();

                                                                                                                                checkBox.setChecked(false);
                                                                                                                                checkBox2.setChecked(false);
                                                                                                                                checkBox3.setChecked(false);
                                                                                                                                checkBox4.setChecked(false);
                                                                                                                                displayResults("Record Updated", "Record successfully updated");
                                                                                                                                extras.clear();


                                                                                                                                // recreate();

                                                                                                                        }

                                                                                                                }
                                                                                                        });
                                                                                                alertDialogBuilder.setNegativeButton("No",
                                                                                                        new DialogInterface.OnClickListener() {
                                                                                                                public void onClick(DialogInterface dialog, int which) {

                                                                                                                }
                                                                                                        });


                                                                                                alertDialogBuilder.setCancelable(true);//.setPositiveButton("OK",
                                                                                                //          new DialogInterface.OnClickListener() {
                                                                                                //  public void onClick(DialogInterface dialog, int id) {
                                                                                                // Cancels the dialog

                                                                                                alertDialogBuilder.show();
                                                                                        }
                                                                                });
                                                                                cancel.setOnClickListener(new View.OnClickListener() {
                                                                                        public void onClick(View view) {
                                                                                                AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(
                                                                                                        MainActivity.this);

                                                                                                alertDialogBuilder.setMessage("Are you sure you discard changes?");
                                                                                                alertDialogBuilder.setPositiveButton("Yes",
                                                                                                        new DialogInterface.OnClickListener() {
                                                                                                                public void onClick(DialogInterface dialog, int which) {
                                                                                                                        add.setVisibility(View.VISIBLE);
                                                                                                                        cancel.setVisibility(View.GONE);
                                                                                                                        update.setVisibility(View.INVISIBLE);
                                                                                                                        Lname.setText(null);
                                                                                                                        Fname.setText(null);
                                                                                                                        Mname.setText(null);
                                                                                                                        rbGroup.clearCheck();
                                                                                                                        checkBox.setChecked(false);
                                                                                                                        checkBox2.setChecked(false);
                                                                                                                        checkBox3.setChecked(false);
                                                                                                                        checkBox4.setChecked(false);


                                                                                                                }
                                                                                                        });
                                                                                                alertDialogBuilder.setNegativeButton("No",
                                                                                                        new DialogInterface.OnClickListener() {
                                                                                                                public void onClick(DialogInterface dialog, int which) {

                                                                                                                }
                                                                                                        });
                                                                                                alertDialogBuilder.setCancelable(true);
                                                                                                alertDialogBuilder.show();
                                                                                        }
                                                                                });

                                                                                //input.setHint("Enter ID");
                                                                                //  input.setLayoutParams(lp);
                                                                                //input.setInputType(InputType.TYPE_CLASS_NUMBER);
                                                                                counter++;
                                                                        }
                                                                        else {
                                                                                Button cancel = (Button) findViewById(btCancelID);
                                                                                Button update = (Button) findViewById(btUpdateID);
                                                                                cancel.setVisibility(View.VISIBLE);
                                                                                update.setVisibility(View.VISIBLE);
                                                                                add.setVisibility(View.INVISIBLE);
                                                                        }
                                                                }




                                                        }
                                                });
                                                builder.setPositiveButton("Search by ID",
                                                        new DialogInterface.OnClickListener() {
                                                                public void onClick(DialogInterface dialog,int which)
                                                                {
                                                                        final AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(
                                                                                MainActivity.this);
                                                                        alertDialogBuilder.setIcon(getResources().getDrawable(R.drawable.search));
                                                                        alertDialogBuilder.setTitle("Search by ID");
                                                                        // alertDialogBuilder.setMessage("Search by Last Name:");
                                                                        alertDialogBuilder.setCancelable(true);//.setPositiveButton("OK",
                                                                        //          new DialogInterface.OnClickListener() {
                                                                        //  public void onClick(DialogInterface dialog, int id) {
                                                                        // Cancels the dialog


                                                                        final EditText input = new EditText(MainActivity.this);
                                                                        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                                                                                LinearLayout.LayoutParams.WRAP_CONTENT,
                                                                                LinearLayout.LayoutParams.WRAP_CONTENT);
                                                                        input.setHint("Enter ID");
                                                                        input.setLayoutParams(lp);
                                                                        alertDialogBuilder.setView(input);
                                                                        input.setInputType(InputType.TYPE_CLASS_NUMBER);
                                                                        final  List<String> mTags = new ArrayList<String>();
                                                                        final ArrayList<String> lname = new ArrayList<String>();
                                                                        final ArrayList<String> fname = new ArrayList<String>();
                                                                        final ArrayList<String> mname = new ArrayList<String>();
                                                                        final ArrayList<String> studID = new ArrayList<String>();

                                                                        // final String[] fname = {};
                                                                        // final String[] mname = {};
                                                                        alertDialogBuilder.setPositiveButton("OK",
                                                                                new DialogInterface.OnClickListener() {
                                                                                        public void onClick(DialogInterface dialog,int which) {

                                                                                                if(input.getText().toString().equalsIgnoreCase(""))
                                                                                                {
                                                                                                        displayResults("", "No Results Found.");
                                                                                                }
                                                                                                else
                                                                                                {
                                                                                                        final AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity.this,R.style.Theme_AppCompat_Dialog_Alert);
                                                                                                        Cursor c = db.rawQuery("SELECT * FROM student", null);

                                                                                                        while (c.moveToNext())
                                                                                                        {
                                                                                                                if(String.valueOf(c.getInt(9)).contains(input.getText().toString()))
                                                                                                                {
                                                                                                                        mTags.add(c.getInt(9)+"  -  " + c.getString(1) + ", " + c.getString(2) + " " + c.getString(3));
                                                                                                                        lname.add(c.getString(1));
                                                                                                                        fname.add(c.getString(2));
                                                                                                                        mname.add(c.getString(3));
                                                                                                                        studID.add(Integer.toString(c.getInt(9)));
                                                                                                                }

                                                                                                        }

                                                                                                        final CharSequence[] tags = mTags.toArray(new String[mTags.size()]);

                                                                                                        if(tags.length==0)
                                                                                                        {
                                                                                                                displayResults("", "No Results Found.");
                                                                                                        }
                                                                                                        else {
                                                                                                                builder.setTitle("Records Found");
                                                                                                                builder.setItems(tags, new DialogInterface.OnClickListener() {
                                                                                                                        public void onClick(DialogInterface dialog, final int item)
                                                                                                                        {
                                                                                                                                Lname = (EditText) findViewById(R.id.editText);
                                                                                                                                Fname = (EditText) findViewById(R.id.editText2);
                                                                                                                                Mname = (EditText) findViewById(R.id.editText3);
                                                                                                                                rbGender1 = (RadioButton) findViewById(R.id.radiobutton);
                                                                                                                                rbGender2 = (RadioButton) findViewById(R.id.radiobutton2);
                                                                                                                                checkBox  = (CheckBox) findViewById(R.id.checkBox);
                                                                                                                                checkBox2  = (CheckBox) findViewById(R.id.checkBox2);
                                                                                                                                checkBox3  = (CheckBox) findViewById(R.id.checkBox3);
                                                                                                                                checkBox4  = (CheckBox) findViewById(R.id.checkBox4);
                                                                                                                                spinner = (Spinner) findViewById(R.id.spinner);
                                                                                                                                rbGroup = (RadioGroup) findViewById(R.id.radioGroup);
                                                                                                                                final Button add = (Button) findViewById(R.id.btAdd);
                                                                                                                                mDrawerLayout = (DrawerLayout)findViewById(R.id.drawer_layout);
                                                                                                                                RelativeLayout rl = (RelativeLayout) findViewById(R.id.r1);
                                                                                                                                Cursor c = db.rawQuery("SELECT * FROM student where id="+ String.valueOf(studID.get(item)), null);
                                                                                                                                updateID= Integer.parseInt(studID.get(item));
                                                                                                                                if(c.moveToFirst()) {

                                                                                                                                        for (int a = 0; a < 5; a++) {
                                                                                                                                                if (spinner.getItemAtPosition(a).toString().equalsIgnoreCase(c.getString(0)))
                                                                                                                                                        spinner.setSelection(a);


                                                                                                                                        }
                                                                                                                                        Lname.setText(c.getString(1));
                                                                                                                                        Fname.setText(c.getString(2));
                                                                                                                                        Mname.setText(c.getString(3));

                                                                                                                                        if(c.getString(4).equalsIgnoreCase("Male")) {
                                                                                                                                                rbGender1.setChecked(true);
                                                                                                                                                rbGender2.setChecked(false);

                                                                                                                                        }
                                                                                                                                        else if(c.getString(4).equalsIgnoreCase("Female"))
                                                                                                                                        {
                                                                                                                                                rbGender2.setChecked(true);
                                                                                                                                                rbGender1.setChecked(false);
                                                                                                                                        }
                                                                                                                                        else if(c.getString(4).equalsIgnoreCase("null"))
                                                                                                                                        {
                                                                                                                                                rbGroup.clearCheck();
                                                                                                                                        }



                                                                                                                                        if (!(c.getString(5).equalsIgnoreCase("null")))
                                                                                                                                                checkBox.setChecked(true);
                                                                                                                                        else
                                                                                                                                                checkBox.setChecked(false);
                                                                                                                                        if (!(c.getString(6).equalsIgnoreCase("null")))
                                                                                                                                                checkBox2.setChecked(true);
                                                                                                                                        else
                                                                                                                                                checkBox2.setChecked(false);
                                                                                                                                        if (!(c.getString(7).equalsIgnoreCase("null")))
                                                                                                                                                checkBox3.setChecked(true);
                                                                                                                                        else
                                                                                                                                                checkBox3.setChecked(false);
                                                                                                                                        if (!(c.getString(8).equalsIgnoreCase("null")))
                                                                                                                                                checkBox4.setChecked(true);
                                                                                                                                        else
                                                                                                                                                checkBox4.setChecked(false);

                                                                                                                                        mDrawerLayout.closeDrawers();


                                                                                                                                        if (counter == 0)
                                                                                                                                        {
                                                                                                                                                final Button update = new Button(MainActivity.this);
                                                                                                                                                final Button cancel = new Button(MainActivity.this);
                                                                                                                                                RelativeLayout.LayoutParams lp = new RelativeLayout.LayoutParams(
                                                                                                                                                        RelativeLayout.LayoutParams.WRAP_CONTENT,
                                                                                                                                                        RelativeLayout.LayoutParams.WRAP_CONTENT);
                                                                                                                                                RelativeLayout.LayoutParams lp2 = new RelativeLayout.LayoutParams(
                                                                                                                                                        RelativeLayout.LayoutParams.WRAP_CONTENT,
                                                                                                                                                        RelativeLayout.LayoutParams.WRAP_CONTENT);
                                                                                                                                                lp.addRule(RelativeLayout.ALIGN_PARENT_BOTTOM, RelativeLayout.TRUE);
                                                                                                                                                lp.addRule(RelativeLayout.ALIGN_PARENT_LEFT, RelativeLayout.TRUE);
                                                                                                                                                update.setBackgroundColor(Color.parseColor("#00a6ff"));
                                                                                                                                                update.setText("Update");
                                                                                                                                                update.setId(View.generateViewId());
                                                                                                                                                btUpdateID= update.getId();
                                                                                                                                                cancel.setText("Cancel");
                                                                                                                                                cancel.setId(View.generateViewId());
                                                                                                                                                btCancelID= cancel.getId();
                                                                                                                                                cancel.setBackgroundColor(Color.parseColor("#00a6ff"));
                                                                                                                                                lp2.addRule(RelativeLayout.ALIGN_PARENT_BOTTOM, RelativeLayout.TRUE);
                                                                                                                                                lp2.addRule(RelativeLayout.ALIGN_PARENT_RIGHT, RelativeLayout.TRUE);
                                                                                                                                                rl.addView(update, lp);
                                                                                                                                                rl.addView(cancel, lp2);
                                                                                                                                                add.setVisibility(View.INVISIBLE);

                                                                                                                                                update.setOnClickListener(new View.OnClickListener() {
                                                                                                                                                        public void onClick(View view) {
                                                                                                                                                                AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(
                                                                                                                                                                        MainActivity.this);

                                                                                                                                                                alertDialogBuilder.setMessage("Are you sure you wanna save the changes?");
                                                                                                                                                                alertDialogBuilder.setPositiveButton("Yes",
                                                                                                                                                                        new DialogInterface.OnClickListener() {
                                                                                                                                                                                public void onClick(DialogInterface dialog, int which) {
                                                                                                                                                                                        // TODO Auto-generated method stub
                                                                                                                                                                                        Lname = (EditText) findViewById(R.id.editText);
                                                                                                                                                                                        int counter = 0;
                                                                                                                                                                                        Fname = (EditText) findViewById(R.id.editText2);
                                                                                                                                                                                        Mname = (EditText) findViewById(R.id.editText3);
                                                                                                                                                                                        checkBox = (CheckBox) findViewById(R.id.checkBox);
                                                                                                                                                                                        checkBox2 = (CheckBox) findViewById(R.id.checkBox2);
                                                                                                                                                                                        checkBox3 = (CheckBox) findViewById(R.id.checkBox3);
                                                                                                                                                                                        checkBox4 = (CheckBox) findViewById(R.id.checkBox4);



                                                                                                                                                                                        if (checkBox.isChecked()) {
                                                                                                                                                                                                extras.putString("Req1", checkBox.getText().toString());
                                                                                                                                                                                        }
                                                                                                                                                                                        if (checkBox2.isChecked())
                                                                                                                                                                                                extras.putString("Req2", checkBox2.getText().toString());
                                                                                                                                                                                        if (checkBox3.isChecked())
                                                                                                                                                                                                extras.putString("Req3", checkBox3.getText().toString());
                                                                                                                                                                                        if (checkBox4.isChecked())
                                                                                                                                                                                                extras.putString("Req4", checkBox4.getText().toString());


                                                                                                                                                                                        extras.putString("Last_Name", Lname.getText().toString());
                                                                                                                                                                                        extras.putString("First_Name", Fname.getText().toString());
                                                                                                                                                                                        extras.putString("Middle_Name", Mname.getText().toString());
                                                                                                                                                                                        Spinner spinner = (Spinner) findViewById(R.id.spinner);
                                                                                                                                                                                        extras.putString("Spinner", spinner.getSelectedItem().toString());


                                                                                                                                                                                        RadioButton radioButton = (RadioButton) findViewById(R.id.radiobutton);
                                                                                                                                                                                        RadioButton radioButton2 = (RadioButton) findViewById(R.id.radiobutton2);


                                                                                                                                                                                        //VALIDATIONS
                                                                                                                                                                                        if (!(radioButton.isChecked() || radioButton2.isChecked())) {
                                                                                                                                                                                                TextView test = (TextView) findViewById(R.id.textView11);
                                                                                                                                                                                                Animation anim = new AlphaAnimation(0.0f, 1.0f);
                                                                                                                                                                                                anim.setDuration(50); //You can manage the blinking time with this parameter
                                                                                                                                                                                                anim.setStartOffset(20);
                                                                                                                                                                                                anim.setRepeatMode(Animation.REVERSE);
                                                                                                                                                                                                anim.setRepeatCount(2);
                                                                                                                                                                                                test.startAnimation(anim);
                                                                                                                                                                                                test.setError("Username Should not be blank");
                                                                                                                                                                                                counter++;
                                                                                                                                                                                        } else {
                                                                                                                                                                                                TextView test = (TextView) findViewById(R.id.textView11);
                                                                                                                                                                                                test.setError(null);
                                                                                                                                                                                                if(radioButton.isChecked())
                                                                                                                                                                                                        extras.putString("radioData", radioButton.getText().toString());
                                                                                                                                                                                                else
                                                                                                                                                                                                        extras.putString("radioData", radioButton2.getText().toString());
                                                                                                                                                                                        }
                                                                                                                                                                                        if (Lname.getText().toString().equalsIgnoreCase("")) {
                                                                                                                                                                                                TextView test = (TextView) findViewById(R.id.textView7);
                                                                                                                                                                                                Animation anim = new AlphaAnimation(0.0f, 1.0f);
                                                                                                                                                                                                anim.setDuration(50); //You can manage the blinking time with this parameter
                                                                                                                                                                                                anim.setStartOffset(20);
                                                                                                                                                                                                anim.setRepeatMode(Animation.REVERSE);
                                                                                                                                                                                                anim.setRepeatCount(2);
                                                                                                                                                                                                test.startAnimation(anim);
                                                                                                                                                                                                test.setError("Username Should not be blank");
                                                                                                                                                                                                counter++;
                                                                                                                                                                                        } else {
                                                                                                                                                                                                TextView test = (TextView) findViewById(R.id.textView7);
                                                                                                                                                                                                test.setError(null);
                                                                                                                                                                                        }

                                                                                                                                                                                        if (Fname.getText().toString().equalsIgnoreCase("")) {
                                                                                                                                                                                                TextView test = (TextView) findViewById(R.id.textView8);
                                                                                                                                                                                                Animation anim = new AlphaAnimation(0.0f, 1.0f);
                                                                                                                                                                                                anim.setDuration(50); //You can manage the blinking time with this parameter
                                                                                                                                                                                                anim.setStartOffset(20);
                                                                                                                                                                                                anim.setRepeatMode(Animation.REVERSE);
                                                                                                                                                                                                anim.setRepeatCount(2);
                                                                                                                                                                                                test.startAnimation(anim);
                                                                                                                                                                                                test.setError("Username Should not be blank");
                                                                                                                                                                                                counter++;
                                                                                                                                                                                        } else {
                                                                                                                                                                                                TextView test = (TextView) findViewById(R.id.textView8);
                                                                                                                                                                                                test.setError(null);
                                                                                                                                                                                        }
                                                                                                                                                                                        if (Mname.getText().toString().equalsIgnoreCase("")) {
                                                                                                                                                                                                TextView test = (TextView) findViewById(R.id.textView9);
                                                                                                                                                                                                Animation anim = new AlphaAnimation(0.0f, 1.0f);
                                                                                                                                                                                                anim.setDuration(50); //You can manage the blinking time with this parameter
                                                                                                                                                                                                anim.setStartOffset(20);
                                                                                                                                                                                                anim.setRepeatMode(Animation.REVERSE);
                                                                                                                                                                                                anim.setRepeatCount(2);
                                                                                                                                                                                                test.startAnimation(anim);
                                                                                                                                                                                                test.setError("Username Should not be blank");
                                                                                                                                                                                                counter++;
                                                                                                                                                                                        } else {
                                                                                                                                                                                                TextView test = (TextView) findViewById(R.id.textView9);
                                                                                                                                                                                                test.setError(null);
                                                                                                                                                                                        }

                                                                                                                                                                                        if (spinner.getSelectedItemPosition() == 0) {

                                                                                                                                                                                        }

                                                                                                                                                                                        //VALIDATIONS CONFIRMATION
                                                                                                                                                                                        if (counter > 0) {
                                                                                                                                                                                                Toast.makeText(MainActivity.this, "Please fill up the necessary informations", Toast.LENGTH_SHORT).show();
                                                                                                                                                                                                counter = 0;
                                                                                                                                                                                        } else {
                                                                                                                                                                                                //INTENT HEREEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEE

                                                                                                                                                                                                db.execSQL("Update student SET AProg ='" + extras.getString("Spinner") + "', LName='" + extras.getString("Last_Name") + "',FName='" + extras.getString("First_Name") + "',MName='" + extras.getString("Middle_Name") + "',Gender='" + extras.getString("radioData") + "',Req1='" + extras.getString("Req1") + "',Req2='" + extras.getString("Req2") + "',Req3='" + extras.getString("Req3") + "',Req4='" + extras.getString("Req4") + "' where ID=" + updateID + ";");

                                                                                                                                                                                                Lname.setText(null);
                                                                                                                                                                                                Lname.requestFocus();
                                                                                                                                                                                                Fname.setText(null);
                                                                                                                                                                                                Mname.setText(null);

                                                                                                                                                                                                rbGroup.clearCheck();

                                                                                                                                                                                                checkBox.setChecked(false);
                                                                                                                                                                                                checkBox2.setChecked(false);
                                                                                                                                                                                                checkBox3.setChecked(false);
                                                                                                                                                                                                checkBox4.setChecked(false);
                                                                                                                                                                                                displayResults("Record Updated", "Record successfully updated");
                                                                                                                                                                                                extras.clear();


                                                                                                                                                                                                // recreate();

                                                                                                                                                                                        }

                                                                                                                                                                                }
                                                                                                                                                                        });
                                                                                                                                                                alertDialogBuilder.setNegativeButton("No",
                                                                                                                                                                        new DialogInterface.OnClickListener() {
                                                                                                                                                                                public void onClick(DialogInterface dialog, int which) {

                                                                                                                                                                                }
                                                                                                                                                                        });
                                                                                                                                                                alertDialogBuilder.setCancelable(true);//.setPositiveButton("OK",
                                                                                                                                                                //          new DialogInterface.OnClickListener() {
                                                                                                                                                                //  public void onClick(DialogInterface dialog, int id) {
                                                                                                                                                                // Cancels the dialog

                                                                                                                                                                alertDialogBuilder.show();
                                                                                                                                                        }
                                                                                                                                                });
                                                                                                                                                cancel.setOnClickListener(new View.OnClickListener() {
                                                                                                                                                        public void onClick(View view) {
                                                                                                                                                                AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(
                                                                                                                                                                        MainActivity.this);

                                                                                                                                                                alertDialogBuilder.setMessage("Are you sure you discard changes?");
                                                                                                                                                                alertDialogBuilder.setPositiveButton("Yes",
                                                                                                                                                                        new DialogInterface.OnClickListener() {
                                                                                                                                                                                public void onClick(DialogInterface dialog, int which) {
                                                                                                                                                                                        add.setVisibility(View.VISIBLE);
                                                                                                                                                                                        cancel.setVisibility(View.GONE);
                                                                                                                                                                                        update.setVisibility(View.INVISIBLE);
                                                                                                                                                                                        Lname.setText(null);
                                                                                                                                                                                        Fname.setText(null);
                                                                                                                                                                                        Mname.setText(null);
                                                                                                                                                                                        rbGroup.clearCheck();
                                                                                                                                                                                        checkBox.setChecked(false);
                                                                                                                                                                                        checkBox2.setChecked(false);
                                                                                                                                                                                        checkBox3.setChecked(false);
                                                                                                                                                                                        checkBox4.setChecked(false);


                                                                                                                                                                                }
                                                                                                                                                                        });
                                                                                                                                                                alertDialogBuilder.setNegativeButton("No",
                                                                                                                                                                        new DialogInterface.OnClickListener() {
                                                                                                                                                                                public void onClick(DialogInterface dialog, int which) {

                                                                                                                                                                                }
                                                                                                                                                                        });
                                                                                                                                                                alertDialogBuilder.setCancelable(true);
                                                                                                                                                                alertDialogBuilder.show();
                                                                                                                                                        }
                                                                                                                                                });

                                                                                                                                                //input.setHint("Enter ID");
                                                                                                                                                //  input.setLayoutParams(lp);
                                                                                                                                                //input.setInputType(InputType.TYPE_CLASS_NUMBER);
                                                                                                                                                counter++;
                                                                                                                                        }
                                                                                                                                        else {
                                                                                                                                                Button cancel = (Button) findViewById(btCancelID);
                                                                                                                                                Button update = (Button) findViewById(btUpdateID);
                                                                                                                                                cancel.setVisibility(View.VISIBLE);
                                                                                                                                                update.setVisibility(View.VISIBLE);
                                                                                                                                                add.setVisibility(View.INVISIBLE);
                                                                                                                                        }
                                                                                                                                }





                                                                                                                        }
                                                                                                                });
                                                                                                                builder.show();
                                                                                                        }
                                    /*alertDialogBuilder.setItems(tags, new DialogInterface.OnClickListener() {
                                        public void onClick(DialogInterface dialog, int item) {
                                            Cursor c = db.rawQuery("SELECT * FROM students WHERE LName='"+ tags[item] + "'", null);
                                            if(c.moveToFirst())
                                            {
                                                db.execSQL("DELETE FROM students WHERE LName='" + tags[item] + "'");

                                            }
                                        }
                                    });*/

                                   /* if(buffer.toString().equalsIgnoreCase(""))
                                        displayResults("", "No Results Found.");
                                    else
                                        displayResults("Student Details", buffer.toString());*/
                                                                                                }

                                                                                        }
                                                                                });
                                                                        alertDialogBuilder.show();
                                                                }
                                                        });


                                                builder.show();
                                        }
                                }
                        }
                });
        }

        private void setupDrawer() {
                mDrawerToggle = new ActionBarDrawerToggle(this, mDrawerLayout, R.string.drawer_open, R.string.drawer_close) {

                        /** Called when a drawer has settled in a completely open state. */
                        public void onDrawerOpened(View drawerView) {
                                super.onDrawerOpened(drawerView);
                                getSupportActionBar().setTitle("Menu");
                                invalidateOptionsMenu(); // creates call to onPrepareOptionsMenu()
                        }

                        /** Called when a drawer has settled in a completely closed state. */
                        public void onDrawerClosed(View view) {
                                super.onDrawerClosed(view);
                                getSupportActionBar().setTitle(mActivityTitle);
                                invalidateOptionsMenu(); // creates call to onPrepareOptionsMenu()
                        }
                };

                mDrawerToggle.setDrawerIndicatorEnabled(true);
                mDrawerLayout.setDrawerListener(mDrawerToggle);
        }

        @Override
        protected void onPostCreate(Bundle savedInstanceState) {
                super.onPostCreate(savedInstanceState);
                // Sync the toggle state after onRestoreInstanceState has occurred.
                mDrawerToggle.syncState();
        }

        @Override
        public void onConfigurationChanged(Configuration newConfig) {
                super.onConfigurationChanged(newConfig);
                mDrawerToggle.onConfigurationChanged(newConfig);
        }



        @Override
        public boolean onOptionsItemSelected(MenuItem item) {
                // Handle action bar item clicks here. The action bar will
                // automatically handle clicks on the Home/Up button, so long
                // as you specify a parent activity in AndroidManifest.xml.
                int id = item.getItemId();
                //noinspection SimplifiableIfStatement
                //  if (id == R.id.action_settings) {
                //     return true;
                // }

                // Activate the navigation drawer toggle
                if (mDrawerToggle.onOptionsItemSelected(item)) {
                        return true;
                }

                return super.onOptionsItemSelected(item);
        }






        public void onRadioButtonClicked(View view) {
                // Is the button now checked?
                RadioButton radioButton = (RadioButton) findViewById(R.id.radiobutton);
                RadioButton radioButton2 = (RadioButton) findViewById(R.id.radiobutton2);
                boolean checked = ((RadioButton) view).isChecked();

                // Check which radio button was clicked
                switch (view.getId()) {
                        case R.id.radiobutton:
                                if (checked)
                                        extras.putString("radioData",radioButton.getText().toString() );
                                break;
                        case R.id.radiobutton2:
                                extras.putString("radioData", radioButton2.getText().toString());
                                if (checked)
                                        break;



                }
        }
        public void displayResults(String title, String description) {
                // Alert Dialog to display the status of the Profile creation
                // operation of MX features
                AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(
                        MainActivity.this, R.style.Theme_AppCompat_Dialog_Alert);

                alertDialogBuilder.setTitle(title);
                alertDialogBuilder.setMessage(description);
                alertDialogBuilder.setCancelable(true);//.setPositiveButton("OK",
                //          new DialogInterface.OnClickListener() {
                //  public void onClick(DialogInterface dialog, int id) {
                // Cancels the dialog

                alertDialogBuilder.show();
                //  }
                //    });
// create alert dialog
                //  AlertDialog alertDialog = alertDialogBuilder.create();
// show it



        }
}
